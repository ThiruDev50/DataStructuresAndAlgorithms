import time
import tracemalloc
from tabulate import tabulate
def get_version():
    return "0.0.3"

class LeetCodeTestingScript:
    def __init__(self,sol):
        self.sol = sol
        
    def log_results(self,test_case_res,expected,actual):
        test_case_res.append("Expected ")
        test_case_res.append(expected)
        test_case_res.append("Received ")
        test_case_res.append(actual)
        
    def convert_byte_to_kilobyte(self, byte):
        return byte / 1024.0
    
    def convert_byte_to_megabyte(self, byte):
        return (byte / 1024.0)/1024.0
    
    def log_memory(self,memory,memory_log_config,test_case_res):
        curr,peak=memory 
        curr_memory_list=[]
        peak_memory_list=[]
        if(memory_log_config.get('enable_peak_memory',0)):
            if(memory_log_config.get('byte',0)):
                peak_memory_list.append(f" {peak:.2f} byte")
            if(memory_log_config.get('kilobyte',0)):
                peak_memory_list.append(f" {self.convert_byte_to_kilobyte(peak):.2f} KB")
            if(memory_log_config.get('megabyte',0)):
                peak_memory_list.append(f" {self.convert_byte_to_megabyte(peak):.2f} MB")
                
        if memory_log_config.get('enable_current_memory',0):
            if(memory_log_config.get('byte',0)):
                curr_memory_list.append(f" {curr:.2f} byte")
            
            if(memory_log_config.get('kilobyte',0)):
                curr_memory_list.append(f" {self.convert_byte_to_kilobyte(curr):.2f} KB")
                
            if(memory_log_config.get('megabyte',0)):
                curr_memory_list.append(f" {self.convert_byte_to_megabyte(curr):.2f} MB")

        if curr_memory_list:
            test_case_res.append("   CMem:"+' , '.join(curr_memory_list))
        if peak_memory_list:
            test_case_res.append("   PMem:"+' , '.join(peak_memory_list))
    def run_tests(self,function_ref,test_config):
        green_start="\033[92m "
        red_start="\033[91m "
        orange_start="\033[94m "
        end_color=" \033[0m"
        test_case_results=[]
        memory_consumed_list=[]
        pass_count=0
        executed_test_count=0
        #Test setup
        testcases=test_config.get('test_cases',[])
        is_compare_with_solution =test_config.get('compare_with_solution',0)
        execute_test_case = test_config.get('execute_test_case',[])
        enable_log =test_config.get('enable_log',1)
        include_test_exec_comp =test_config.get('include_test_exec_comparison',1)
        include_failed_testcase_comparison =test_config.get('include_failed_testcase_comparison',1)
        memory_config =test_config.get('memory_log',{})
        enable_memory_log=memory_config.get('enable_memory_log',0)
        include_overall_memory_consumed=test_config.get('include_overall_memory_consumed',0)
        memory_log_details_config=memory_config.get('memory_log_details',{})
        
        if(is_compare_with_solution and hasattr(self.sol, 'solution')):
            print(red_start+" Could not find solution but compare_with_solution is True"+end_color)
            return
            
        
        for i in range(len(testcases)):
            test_case_res=[]
            test_case_num=(i+1)
            testcase_number_str=str(test_case_num)
            elapsed_time_ticks=0
            is_test_case_failed=False
            
            try:
                if enable_log:
                    print("Execution started for Test ",testcase_number_str)
                if len(execute_test_case)>0 and test_case_num not in execute_test_case:
                    if enable_log:
                        print(orange_start+"Execution Skipped for Test "+testcase_number_str+end_color)
                    test_case_res.append(orange_start+" Test "+testcase_number_str+" Skipped! "+end_color)
                    continue
                executed_test_count+=1
                inputs = testcases[i]["Input"]
                tracemalloc.start()
                start_time_ticks = time.perf_counter()
                res = function_ref(*inputs)
                end_time_ticks = time.perf_counter()
                memory_consumed=tracemalloc.get_traced_memory()
                tracemalloc.stop()
                memory_consumed_list.append(memory_consumed)
                elapsed_time_ticks = int((end_time_ticks - start_time_ticks) * 1e6)
                expected_res=None
                if(is_compare_with_solution):
                    expected_res=self.sol.solution(*inputs)
                else:
                    expected_res=testcases[i]["Output"]
                if res==expected_res:
                    test_case_res.append(green_start+" Test "+testcase_number_str+" Passed!  "+end_color)
                    pass_count+=1
                else:
                    test_case_res.append(red_start+" Test "+testcase_number_str+" Failed!  "+end_color)
                    is_test_case_failed=True
                if enable_memory_log:
                    self.log_memory(memory_consumed,memory_log_details_config,test_case_res)
                if include_test_exec_comp or (is_test_case_failed and include_failed_testcase_comparison):
                    self.log_results(test_case_res,expected_res,res)
            except Exception as e:
                test_case_res.append("Error while executing Test "+testcase_number_str+" Error : "+str(e))
            finally: 
                test_case_res.insert(1,"Time taken :"+str(elapsed_time_ticks)+" ticks")
                test_case_results.append(test_case_res)
                
                if enable_log:
                    print("Execution completed for Test ",testcase_number_str)
              
        print("****************Results Start**********************")  
       
        table = tabulate(test_case_results, [], tablefmt="fancy_grid")
        print(table)
        print((green_start if executed_test_count==pass_count else red_start)+"Test case summary : "+(str(pass_count))+"/"+str(len(testcases))+end_color)
        if(include_overall_memory_consumed and len(memory_consumed_list)>0):
            total_curr_memory_in_byte = 0
            total_peak_memory_in_byte = 0
            for ele in memory_consumed_list:
                currSize,peakSize=ele
                total_curr_memory_in_byte+=currSize
                total_peak_memory_in_byte+=peakSize
            avg_curr_memory_in_byte = total_curr_memory_in_byte/len(memory_consumed_list)
            avg_peak_memory_in_byte = total_peak_memory_in_byte/len(memory_consumed_list)
            print(f"Total CMem : {total_curr_memory_in_byte} byte,  Total PMem : {orange_start} {total_peak_memory_in_byte} byte {end_color}") 
            print(f"Average CMem : {avg_curr_memory_in_byte} byte,  Total PMem : {orange_start} {avg_peak_memory_in_byte} byte {end_color}") 
        print("****************Results End**********************")  

 
     
class TestClass:
    def __init__(self):
        print("Test class initiated")