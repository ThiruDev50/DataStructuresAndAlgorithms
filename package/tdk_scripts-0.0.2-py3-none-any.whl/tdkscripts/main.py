import time

def get_version():
    return "0.0.2"

class TestingScript:
    def __init__(self,sol):
        self.sol = sol
        
    def log_results(self,test_case_res,expected,actual):
        test_case_res.append("- Expected ")
        test_case_res.append(expected)
        test_case_res.append("Received ")
        test_case_res.append(actual)
        
    def run_tests(self,function_ref,test_config):
        green_start="\033[92m "
        red_start="\033[91m "
        orange_start="\033[94m "
        end_color=" \033[0m"
        test_case_results=[]
        pass_count=0
        executed_test_count=0
        #Test setup
        testcases=test_config.get('test_cases',[])
        is_compare_with_solution = test_config.get('compare_with_solution',False)
        execute_test_case = test_config.get('execute_test_case',[])
        enable_log = test_config.get('enable_log',True)
        if(is_compare_with_solution and self.sol.solution is None):
            print(red_start+" Could not find solution but compare_with_solution is True"+end_color)
            return
            
        
        for i in range(len(testcases)):
            test_case_res=[]
            test_case_num=(i+1)
            testcase_number_str=str(test_case_num)
            elapsed_time_ticks=0
            
            
            try:
                if enable_log:
                    print("Execution started for Test ",testcase_number_str)
                if len(execute_test_case)>0 and test_case_num not in execute_test_case:
                    test_case_res.append(orange_start+" Test "+testcase_number_str+" Skipped! "+end_color)
                    continue
                executed_test_count+=1
                inputs = testcases[i]["Input"]
                start_time_ticks = time.perf_counter()
                res = function_ref(*inputs)
                end_time_ticks = time.perf_counter()
                elapsed_time_ticks = int((end_time_ticks - start_time_ticks) * 1e6)
                expected_res=None
                if(is_compare_with_solution):
                    expected_res=self.sol.solution(*inputs)
                else:
                    expected_res=testcases[i]["Output"]
                if res==expected_res:
                    test_case_res.append(green_start+" Test "+testcase_number_str+" Passed!  "+end_color)
                    pass_count+=1
                else:
                    test_case_res.append(red_start+" Test "+testcase_number_str+" Failed!  "+end_color)
                if enable_log:
                    self.log_results(test_case_res,expected_res,res)
            except Exception as e:
                test_case_res.append("Error while executing Test "+testcase_number_str+" Error : "+str(e))
            finally: 
                test_case_res.insert(1,"Time taken :"+str(elapsed_time_ticks)+" ticks")
                test_case_results.append(test_case_res)
                if enable_log:
                    print("Execution completed for Test ",testcase_number_str)
              
        print("****************Results Start**********************")  
        for i in test_case_results:
            for j in i:
                print(j,end=" ")
            print()
        
        print((green_start if executed_test_count==pass_count else red_start)+"Test case summary : "+(str(pass_count))+"/"+str(len(testcases))+end_color)
        print("****************Results End**********************")  

     
class TestClass:
    def __init__(self):
        print("Test class initiated")