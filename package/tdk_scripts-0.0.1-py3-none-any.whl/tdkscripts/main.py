def hi():
    return "Hello, world!"